# Description:

This is a todo application project built with React following youtuber DevEd.

# Development Tools and Technologies: 
Framework: ReactJS <br>
Deploy Platform: Heroku 

# Project footage:

![todo](https://user-images.githubusercontent.com/36873497/103258277-9cfd0500-49e8-11eb-93fe-b239ee64bfdc.png)


# Link:
 https://fierce-chamber-76105.herokuapp.com/
